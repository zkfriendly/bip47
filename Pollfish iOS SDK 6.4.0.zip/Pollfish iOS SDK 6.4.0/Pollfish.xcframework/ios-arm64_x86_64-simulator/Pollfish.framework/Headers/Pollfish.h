//
//  Pollfish.h
//  Pollfish
//
//  Created by Fotis Mitropoulos on 13/7/20.
//  Copyright © 2020 Pollfish. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Pollfish.
FOUNDATION_EXPORT double PollfishVersionNumber;

//! Project version string for Pollfish.
FOUNDATION_EXPORT const unsigned char PollfishVersionString[];
